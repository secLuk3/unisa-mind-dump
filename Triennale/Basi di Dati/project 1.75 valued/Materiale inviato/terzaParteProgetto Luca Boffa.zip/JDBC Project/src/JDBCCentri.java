import java.sql.*;

public class JDBCCentri 
		{

	public JDBCCentri() 
			{
		
				try
				{
					Class.forName("com.mysql.cj.jdbc.Driver");
					this.con = DriverManager.getConnection("jdbc:mysql://localhost/gestionecentrisportivi?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC", USER, PASSWORD);
					System.out.println("Connessione riuscita");
					this.s = con.createStatement();	
				}
				
				catch(Exception e)
				{
					System.out.println(e);
				}
				
			}
			
			public JDBCCentri(String user, String password)
			{
				try
				{
					Class.forName("com.mysql.cj.jdbc.Driver");
					this.con = DriverManager.getConnection("jdbc:mysql://localhost/gestionecentrisportivi?user="+user+"&password="+password+"useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC", USER, PASSWORD);
					System.out.println("Connessione riuscita");
					this.s = con.createStatement();				
				}
				
				catch(Exception e)
				{
					System.out.println(e);
				} 
			} 
			
			public Statement getStatement() { return s; }
			
			
			private Connection con;
			private Statement s;
			
			private final String USER = "root";
			private final String PASSWORD = "Formula1";
		}


