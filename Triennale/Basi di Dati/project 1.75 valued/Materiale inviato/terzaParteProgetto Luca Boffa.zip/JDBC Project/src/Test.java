
public class Test {

	

	public static void main(String[] args) {
	
		Menu tester = new Menu();
		tester.exeQuery();
		
	}

}
