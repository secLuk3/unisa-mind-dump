import java.sql.*;
import java.util.*;


public class Menu {

	public Menu() {
		
		JDBCCentri connessione = new JDBCCentri();
		this.s = connessione.getStatement();
	}

	public void exeQuery()
	{
		boolean quit = false;
		
		
		while(!quit)
		{
			
			System.out.println("Inserisci l`operazione scelta");
			int scelta = menuLine.nextInt();
			
		switch(scelta) {
		case 1:
			try
			{
				Op1();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
				
		break;
		case 2:
			try
			{
				Op2();
			}
			catch(Exception e)
			{
			 e.printStackTrace();
			}
		break;
		
		case 3:
			try
			{
				Op3();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		
			
			break;
			
		case 4:
			try
			{
				Op4();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			break;
		case 5:
			try
			{
				Op5();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			break;
		case 6:
			try
			{
				Op6();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			break;
		case 7:
			try
			{
				Op7();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			break;
		case 8:
			try
			{
				Op8();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			break;
		case 9:
			try
			{
				Op9();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			break;
		case 10:
			try
			{
				Op10();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			break;
		case 11:
			try
			{
				Op11();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			break;
		case 12:
			try
			{
				Op12();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			break;
		case 13:
			try
			{
				Op13();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			break;
		default:
			System.out.println("Riavvia sarai piu fortunato");
			break;
		}
		if(scelta < 1 || scelta > 15)
			quit = true;
		}
	}	
		private void Op1() throws SQLException
		{
			Scanner s = new Scanner(System.in);
			
		
			//indentificazione segretario
			
			System.out.println("Inserisci il tuo codice segretario :   ");
			String codiceS = in.next();
			
			//verifico se il codice scelto dal segretario  esiste nel dB
			rs = this.s.executeQuery(" select Cf\r\n" + 
					"from segretario\r\n");
			
			boolean presente = false;
			while(rs.next())
			{
				String cfDB= rs.getString("Cf");
				
				if( codiceS.equalsIgnoreCase(cfDB) )
				{
					presente = true;
				}
				
			}
			if(!presente)
			{
				System.out.println("Codice non abilitato a prenotare");
				s.close();
				return;
			}
			
			if(presente)
			{
			System.out.println("Inserisci codice della struttura ");
			int codiceIn = in.nextInt();
			System.out.println("Inserisci nome centro: ");
			String nome = s.nextLine();
			
			System.out.println("Inserisci data(AAAA:MM:GG): ");
			String dataIn = s.nextLine();
			
			System.out.println("--------------LE PRENOTAZIONI SI POSSONO FARE SOLO NELLE ORE IN PUNTO (HH)-------------");
			System.out.println("Inserisci ora: ");
			//forzatura dell orario in punto
			int ora1 = in.nextInt();
			String ora =  ora1+":00:00";
			
				if(Op2(codiceIn , nome , dataIn , ora))
				{
					 this.s.executeUpdate(" insert into gestionecentrisportivi.prenotazione \r\n" +
							"( CodiceStruttura , NomeCentro , CfSegretario , Data , Ora)\r\n " + 
							"values ("  + "'"+ codiceIn + "'" + ","  
											+ "'" + nome + "'" + "," 
											+ "'" + codiceS + "'" + "," 
											+ "'" + dataIn + "'" + ","  
											+ "'" + ora + "'"   +")" );
						

				}
			
			}
			s.close();
		}
		
		private boolean Op2() throws SQLException
		{	
			Scanner s = new Scanner(System.in);
			System.out.println("Inserisci codice della struttura ");
			int codiceIn = in.nextInt();
			System.out.println("Inserisci nome centro: ");
			String nome = s.nextLine();
			
			//verifico se la struttura scelta dall''utente esiste nel dB
			rs = this.s.executeQuery(" select Codice, NomeCentro\r\n" + 
					"from struttura\r\n");
			
			boolean presente = false;
			while(rs.next())
			{
				int codDB= rs.getInt("Codice");
				String nomeDB=rs.getString("NomeCentro");
				if( nome.equalsIgnoreCase(nomeDB) && (codiceIn == codDB))
				{
					presente = true;
				}
				
			}
			if(!presente)
			{
				System.out.println("Struttura non presente nel DB");
				s.close();
				return false;
			}
		
			//parte confronto data e ora
			System.out.println("Inserisci data(AAAA:MM:GG): ");
			String dataIn = s.nextLine();
			
			System.out.println("--------------LE PRENOTAZIONI SI POSSONO FARE SOLO NELLE ORE IN PUNTO (HH)-------------");
			System.out.println("Inserisci ora: ");
			//forzatura dell orario in punto
			int ora1 = in.nextInt();
			String ora =  ora1+":00:00";
		
			rs = this.s.executeQuery(" SELECT data, ora\r\n" + 
					"			FROM prenotazione\r\n" + 
					"			where Data = " + " ' "+ dataIn + " ' "+ "and Ora = " +  " ' "+ ora + " ' ");
					
			boolean presente2 = false;
			while(rs.next())
			{
				String  dataDB= rs.getString("Data");
				String oraDB=rs.getString("Ora");
				if( dataIn.equalsIgnoreCase(dataDB) && ora.equalsIgnoreCase(oraDB) )
				{
					presente2 = true;
				}	
			}
			
			if(presente2)
			{
				System.out.println("Struttura non prenotabile");
				s.close();
				return false;
			}
			
			System.out.println("Struttura prenotabile");
			s.close();
			return true;
	}
		
		private boolean Op2(int codiceIn , String nome , String dataIn , String ora ) throws SQLException
		{	
			
			//verifico se la struttura scelta dall''utente esiste nel dB
			rs = this.s.executeQuery(" select Codice, NomeCentro\r\n" + 
					"from struttura\r\n");
			
			boolean presente = false;
			while(rs.next())
			{
				int codDB = rs.getInt("Codice");
				String nomeDB = rs.getString("NomeCentro");
				if( nome.equalsIgnoreCase(nomeDB) && (codiceIn == codDB))
				{
					presente = true;
				}
				
			}
			if(!presente)
			{
				System.out.println("Struttura non presente nel DB");
				return false;
			}
		
			rs = this.s.executeQuery(" SELECT data, ora\r\n" + 
					"			FROM prenotazione\r\n" + 
					"			where Data = " + " ' "+ dataIn + " ' "+ "and Ora = " +  " ' "+ ora + " ' ");
					
			boolean presente2 = false;
			while(rs.next())
			{
				String  dataDB = rs.getString("Data");
				String oraDB = rs.getString("Ora");
				if( dataIn.equalsIgnoreCase(dataDB) && ora.equalsIgnoreCase(oraDB) )
				{
					presente2 = true;
				}	
			}
			
			if(presente2)
			{
				System.out.println("Struttura non prenotabile");
				return false;
			}
			
			System.out.println("Struttura prenotabile");
			return true;

	}
		
		private void Op3() throws SQLException
		{
			Scanner s = new Scanner(System.in);
			
			System.out.println("Inserisci codice della struttura ");
			int codiceIn = in.nextInt();
			System.out.println("Inserisci nome centro: ");
			String nome = s.nextLine();
			
			//verifico se la struttura scelta dall''utente esiste nel dB
			rs = this.s.executeQuery(" select Codice, NomeCentro\r\n" + 
					"from struttura\r\n");
			
			boolean presente = false;
			while(rs.next())
			{
				int codDB= rs.getInt("Codice");
				String nomeDB=rs.getString("NomeCentro");
				if( nome.equalsIgnoreCase(nomeDB) && (codiceIn == codDB))
				{
					presente = true;
				}
				
			}
			if(!presente)
			{
				System.out.println("Struttura non presente nel DB");
				s.close();
				return;
			}
		
			
			//ricerca giorno 
			System.out.println("Inserisci data(AAAA-MM-GG) da cercare : ");
			String dataIn = s.nextLine();
			
			System.out.println("--------------LE PRENOTAZIONI SI POSSONO FARE SOLO NELLE ORE IN PUNTO (HH)-------------");
			
			rs = this.s.executeQuery(" SELECT data, ora\r\n" + 
					"			FROM prenotazione\r\n" + 
					"			where Data = " + " ' "+ dataIn + " ' ");
			
			System.out.println("---------Il " +dataIn  +" non � possibile prenotare nei seguenti orari :");
			
			while(rs.next())
			{
				String  dataDB = rs.getString("Data");
				String oraDB = rs.getString("Ora"); 
				
				if( dataIn.equalsIgnoreCase(dataDB) )
				{
					System.out.print(oraDB +" || ");
				}
			}
			
			System.out.println("");
			s.close();
		}
		
		
		private void Op4() throws SQLException
		{
			Scanner s = new Scanner(System.in);
			
			System.out.println("Inserisci codice della struttura ");
			int codiceIn = in.nextInt();
			System.out.println("Inserisci nome centro: ");
			String nome = s.nextLine();
			
			//verifico se la struttura scelta dall''utente esiste nel dB
			rs = this.s.executeQuery(" select Codice, NomeCentro\r\n" + 
					"from struttura\r\n");
			
			boolean presente = false;
			while(rs.next())
			{
				int codDB= rs.getInt("Codice");
				String nomeDB=rs.getString("NomeCentro");
				if( nome.equalsIgnoreCase(nomeDB) && (codiceIn == codDB))
				{
					presente = true;
				}
				
			}
			if(!presente)
			{
				System.out.println("Struttura non presente nel DB");
				s.close();
				return;
			}
		
			
			//ricerca giorno 
			System.out.println("Inserisci ora da cercare : ");
			String ora = s.nextLine();
			
			System.out.println("--------------LE PRENOTAZIONI SI POSSONO FARE SOLO NELLE ORE IN PUNTO (HH)-------------");
			
			System.out.println("---------Alle " +ora  +" non � possibile prenotare la struttura  nei seguenti giorni :");
			
			ora = ora+":00:00";
			
			rs = this.s.executeQuery(" SELECT data, ora\r\n" + 
					"			FROM prenotazione\r\n" + 
					"			where ora = " + " ' "+ ora + " ' ");
			
			while(rs.next())
			{
				String  dataDB = rs.getString("Data");
				String oraDB = rs.getString("Ora"); 
				
				if( ora.equalsIgnoreCase(oraDB) )
				{
					System.out.print(dataDB +" || ");
				}
			}
			
			System.out.println("");
			s.close();
		}
		
		private void Op5() throws SQLException 
		{
			Scanner s = new Scanner(System.in);
			
			System.out.println("Inserisci codice della struttura ");
			int codiceIn = in.nextInt();
			System.out.println("Inserisci nome centro: ");
			String nome = s.nextLine();
			
			//verifico se la struttura scelta dall''utente esiste nel dB
			rs = this.s.executeQuery(" select Codice, NomeCentro\r\n" + 
					"from struttura\r\n");
			
			boolean presente = false;
			while(rs.next())
			{
				int codDB= rs.getInt("Codice");
				String nomeDB=rs.getString("NomeCentro");
				if( nome.equalsIgnoreCase(nomeDB) && (codiceIn == codDB))
				{
					presente = true;
				}
				
			}
			if(!presente)
			{
				System.out.println("Struttura non presente nel DB");
				s.close();
				return;
			}
			
			if(presente)
			{
				System.out.println("Inserisci codice dell'attivita: ");
				int attivitaIn = in.nextInt();
				
				//verifico se l'attivita esiste nel BD
				rs = this.s.executeQuery(" select Codice \r\n" + 
						"from attivita\r\n");
				
				presente = false;
				while(rs.next())
				{
					int codaDB= rs.getInt("Codice");
					if((attivitaIn == codaDB))
					{
						presente = true;
					}
					
				}
				if(!presente)
				{
					System.out.println("Attivita non presente non presente nel DB");
					s.close();
					return;
				}	
				if(presente)
				{
					System.out.println("Inserisci data (AAAA-GG-MM) :");
					String dataS = s.nextLine();
					System.out.println("Inserisci ora (HH) :");
					int orat = in.nextInt();
					String oraS = orat +":00:00";
					System.out.println("Inserisci durata (HH:MM:ss) : ");
					String durataS = s.nextLine();
					
					 this.s.executeUpdate(" insert into svolgimento \r\n" +
								"( CodiceAttivita , NomeCentro , CodiceStruttura , Data , Ora , Durata )\r\n " + 
								"values ("  + "'" +attivitaIn +"'" + ","  
												+ "'" + nome + "'" + "," 
												+ "'" + codiceIn + "'" + "," 
												+ "'" + dataS + "'" + ","  
												+ "'" + oraS + "'" + ","  
												+ "'" + durataS + "'" +")" );
				}
			}
		}
		
		private void Op6() throws SQLException
		{
			rs = this.s.executeQuery(" SELECT NomeCentro , CodiceStruttura ,  SEC_TO_TIME( SUM( TIME_TO_SEC( durata ) ) ) AS tempo_totale\r\n"  
					+"from svolgimento\r\n"
					+ "group by codiceAttivita\r\n");
			
			System.out.println("Codice Struttura\tNome Centro\tTempo");
			System.out.println("_____________________________________________");
			
			while(rs.next())
			{
				int codDB= rs.getInt("CodiceStruttura");
				String nomeDB=rs.getString("NomeCentro");
				String timeDB=rs.getString("tempo_totale");
				
				System.out.println(codDB +" \t\t " +nomeDB +" \t\t " +timeDB +"  " );
			}
		}
		
		private void Op7() throws SQLException
		{
				Scanner s = new Scanner(System.in);
			
			
			System.out.println("Inserisci nome centro: ");
			String nome = s.nextLine();
			System.out.println("Inserisci codice dell'attivita: ");
			int codiceIn = in.nextInt();
			
			rs = this.s.executeQuery(" select CodiceAttivita, NomeCentro\r\n" + 
					"from pianificazione \r\n");
			
			boolean presente = false;
			while(rs.next())
			{
				int codDB= rs.getInt("CodiceAttivita");
				String nomeDB=rs.getString("NomeCentro");
				if( nome.equalsIgnoreCase(nomeDB) && (codiceIn == codDB))
				{
					presente = true;
				}
				
			}
			if(presente)
			{
				System.out.println("Attivita gia pianificata");
				s.close();
				return;
			}
			else
			{
					 this.s.executeUpdate(" insert into pianificazione \r\n" +
								"(  NomeCentro , CodiceAttivita )\r\n " + 
								"values ("  + "'" + nome + "'" + "," 
											+ "'" + codiceIn + "'" +")" );
				}
			}
		
		
		private void Op8() throws SQLException
		{
			Scanner s = new Scanner(System.in);
			
			System.out.println("Inserisci codice fiscale dell' allenatore ");
			String nome = s.nextLine();
			
			//verifico se l'allenatore scelto dall''utente esiste nel dB
			rs = this.s.executeQuery(" select Cf \r\n" + 
					"from allenatore\r\n");
			
			boolean presente = false;
			while(rs.next())
			{
				String nomeDB=rs.getString("Cf");
				if( nome.equalsIgnoreCase(nomeDB) )
				{
					presente = true;
					System.out.println("Allenatore gi� presente nel DB");
					
				}
			}	
			
			if(!presente)
			{
		
				String cfA = nome;
				System.out.println("Inserisci nome");
				String nomeA = s.nextLine();
				System.out.println("Inserisci Cognome");
				String cognomeA = s.nextLine();
				System.out.println("Inserisci Telefono");
				String telA = s.nextLine();
				System.out.println("Inserisci tipo contratto");
				String contrattoA = s.nextLine();
				System.out.println("Inserisci anni Esperienza");
				String anniEA = s.nextLine();
				System.out.println("E specializzato?  premi invio per risporta negativa"
						+ " || scriti il tipo per la specializzazione");
				String specA = s.nextLine();
				System.out.println("Inserisci il Documento di speciaizzazione || premi invio per risporta negativa\"\r\n" + 
						"						+ \" || scriti il tipo per la specializzazione ");
				String docSpecA = s.nextLine();
				System.out.println("Inserisci il tipo specializzazione || premi invio per risporta negativa\"\r\n" + 
						"						+ \" || scriti il tipo per la specializzazione");
				String tipoSpecA = s.nextLine();
				
				 this.s.executeUpdate(" insert into allenatore \r\n" +
							"( Cf , Nome , Cognome , Telefono , TipoContratto , AnniEsperienza , Tipoallenatore , DocumentoSpecializzazione , TipoSpecializzazione)\r\n " + 
							"values ("  + "'" +cfA +"'" + ","  
											+ "'" + nomeA + "'" + "," 
											+ "'" + cognomeA + "'" + "," 
											+ "'" + telA + "'" + ","  
											+ "'" + contrattoA + "'" + ","  
											+ "'" + anniEA + "'" + ","  
											+ "'" + specA + "'" + ","  
											+ "'" + docSpecA + "'" + ","  
											+ "'" + tipoSpecA + "'"   +")" );
				
				s.close();
				return;
			}
		}
		
		private void Op9() throws SQLException
		{
			rs = this.s.executeQuery(" select max(numero_attivita) as Numero_Attivita , codicestruttura  , nomecentro\r\n"  
					+"from (\r\n"
					+ "SELECT codiceStruttura , count(codiceattivita) as numero_attivita ,NomeCentro\r\n"
					+ "from svolgimento\r\n"
					+ "where data > (YEAR(data) = YEAR(CURDATE()-1))\r\n"   //anno corrente
					+ "	group by CodiceStruttura\r\n"
					+  ") as motheralias\r\n");
			
			System.out.println("Codice Struttura\tNome Centro\tNumero di attivita svolte");
			System.out.println("_______________________________________________________________");
			
			while(rs.next())
			{
				int codDB= rs.getInt("codicestruttura");
				String nomeDB=rs.getString("nomecentro");
				int numDB = rs.getInt("numero_attivita");
				
				System.out.println(codDB +" \t\t " +nomeDB +" \t\t " +numDB +"  " );
				
			}
		}
		
		private void Op10() throws SQLException
		{
			
			System.out.println("Inserisci codice dell'attivita per cercare le specializzazioni: ");
			int attivitaIn = in.nextInt();
			
			//verifico se l'attivita esiste nel BD
			rs = this.s.executeQuery(" select Codice \r\n" + 
					"from attivita\r\n");
			
			boolean presente = false;
			
			presente = false;
			while(rs.next())
			{
				int codaDB= rs.getInt("Codice");
				if((attivitaIn == codaDB))
				{
					presente = true;
				}
				
			}
			if(!presente)
			{
				System.out.println("Attivita non presente non presente nel DB");
				s.close();
				return;
			}	
			else
			{
				
				rs = this.s.executeQuery(" select nome ,cognome\r\n"  
						+"from allenatore\r\n"
						+ "where TipoSpecializzazione = "  +"\""  + attivitaIn   + "\"" +"\r\n");	
				
				System.out.println("Nome\tCognome\t");
				System.out.println("_______________________________________________________________");
				
				while(rs.next())
				{
					String nomDB= rs.getString("nome");
					String cogDB= rs.getString("cognome");
					
					System.out.println( nomDB + "\t " +cogDB + "\t" );	
				}	
				
			}
			
		}
		
		private void Op11() throws SQLException
		{
			
			Scanner s = new Scanner(System.in);
			
			//indentificazione responsabile
			
			System.out.println("Inserisci il tuo codice fiscale da rimuovere :   ");
			String codiceS = in.next();
			
			//verifico se il codice fiscale del responsabile  esiste nel dB
			rs = this.s.executeQuery(" select Cf\r\n" + 
					"from responsabile\r\n");
			
			boolean presente = false;
			while(rs.next())
			{
				String cfDB= rs.getString("Cf");
				
				if( codiceS.equalsIgnoreCase(cfDB) )
				{
					presente = true;
				}
				
			}
			if(!presente)
			{
				System.out.println("Codice Fiscale Errato!");
				s.close();
				return;
			}
			
			else 
			{
				this.s.executeUpdate("delete from responsabile\r\n"
										+"where Cf = " +"\'"  +codiceS +"\' \r\n"  );
				
				System.out.println("Responasabile eliminato correttamente");
				
				System.out.println("------------------Inserimento nuovo responsabile----------------");
				
				System.out.println("Inserisci Cf:");
				String cfA = s.nextLine();
				System.out.println("Inserisci nome:");
				String nomeA = s.nextLine();
				System.out.println("Inserisci Cognome:");
				String cognomeA = s.nextLine();
				System.out.println("Inserisci Telefono:");
				String telA = s.nextLine();
				System.out.println("Inserisci tipo contratto:");
				String contrattoA = s.nextLine();
				
				this.s.executeUpdate(" insert into responsabile \r\n" +
						"( Cf , Nome , Cognome , Telefono , TipoContratto ) "+
						"values ("  + "'" +cfA +"'" + ","  
										+ "'" + nomeA + "'" + "," 
										+ "'" + cognomeA + "'" + "," 
										+ "'" + telA + "'" + ","  
										+ "'" + contrattoA + "'" + ")" );
				
				
				
				
			}
			
		}
		
		private void Op12() throws SQLException
		{
			
			Scanner s = new Scanner(System.in);
			System.out.println("Inserisci codice della struttura sul quale modificare la prenotazione ");
			int codiceIn = in.nextInt();
			System.out.println("Inserisci nome centro della struttura : ");
			String nome = s.nextLine();
			
			//verifico se la struttura scelta dall''utente esiste nel dB
			rs = this.s.executeQuery(" select Codice, NomeCentro\r\n" + 
					"from struttura\r\n");
			
			boolean presente = false;
			while(rs.next())
			{
				int codDB= rs.getInt("Codice");
				String nomeDB=rs.getString("NomeCentro");
				if( nome.equalsIgnoreCase(nomeDB) && (codiceIn == codDB))
				{
					presente = true;
				}
				
			}
			if(!presente)
			{
				System.out.println("Struttura non presente nel DB");
				s.close();
				return;
			}
			
			//parte confronto data e ora
			System.out.println("Inserisci data(AAAA:MM:GG) da modificare: ");
			String dataIn = s.nextLine();
			
			System.out.println("--------------NOTA LE PRENOTAZIONI SI POSSONO FARE SOLO NELLE ORE IN PUNTO (HH)-------------");
			System.out.println("Inserisci ora da modificare : ");
			//forzatura dell orario in punto
			int ora1 = in.nextInt();
			String ora =  ora1+":00:00";
			
			System.out.println("Inserisci ora modificata : ");
			//inserimento ora modificata
			int ora2 = in.nextInt();
			String ora3 =  ora2+":00:00";
			
		
			rs = this.s.executeQuery(" SELECT data, ora\r\n" + 
					"			FROM prenotazione\r\n" + 
					"			where Data = " + " ' "+ dataIn + " ' "+ "and Ora = " +  " ' "+ ora + " ' ");
					
			boolean presente2 = false;
			while(rs.next())
			{
				String  dataDB= rs.getString("Data");
				String oraDB=rs.getString("Ora");
				if( dataIn.equalsIgnoreCase(dataDB) && ora.equalsIgnoreCase(oraDB) )
				{
					
					presente2 = true;
					
				}	
				
			}
				if(presente2)
				{
					this.s.executeUpdate("update prenotazione \r\n" + 
							"			set ora = " + "\'"  +ora3   +"\'\r\n" + 
							"			where ( Data = " + " \' " + dataIn + " \' "+ "and Ora = " +  " \' "+ ora + " \' "   +" and codicestruttura= " +" \' "+codiceIn  + " \' "+ "and nomecentro= " +  " \' "+nome + " \' " +")" );
				}
				else
				{
					System.out.println("Modifica non effettuata");
				}
		} 
		
		private void Op13() throws SQLException
		{
			Scanner s = new Scanner(System.in);
			System.out.println("Inserisci codice dell'attivita da caricare: ");
			int attivitaIn = in.nextInt();
			
			//verifico se l'attivita esiste nel BD
			rs = this.s.executeQuery(" select Codice \r\n" + 
					"from attivita\r\n");
			
			boolean presente = false;
			
			presente = false;
			while(rs.next())
			{
				int codaDB= rs.getInt("Codice");
				if((attivitaIn == codaDB))
				{
					presente = true;
				}
				
			}
			if(!presente)
			{
				System.out.println("Attivita non presente non presente nel DB");
				s.close();
				return;
			}	
			else
			{
				System.out.println("Inserisci nome centro: ");
				String nome = s.nextLine();
				
				//verifico se il centro scelto dall''utente esiste nel dB
				rs = this.s.executeQuery(" select Nome\r\n" + 
						"from centro\r\n");
				
				presente = false;
				while(rs.next())
				{
					String nomeDB=rs.getString("Nome");
					if( nome.equalsIgnoreCase(nomeDB) )
					{
						presente = true;
					}
					
				}
				if(!presente)
				{
					System.out.println("Centro non presente nel DB");
					s.close();
					return ;
				}
				else
				{
					
					System.out.println("Inserisci periodicita ( n/settimana):");
					String perC = s.nextLine();
					System.out.println("Inserisci durata (HH:mm:ss):");
					String durC = s.nextLine();
					
					this.s.executeUpdate(" insert into corso \r\n" +
							"( codiceattivita , periodicita ,  durata ) "+
							"values ("  + "'" +attivitaIn +"'" + ","  
											+ "'" +perC   + "'" + "," 
											+ "'" +durC   + "'"   + ")" );
					
					System.out.println("Coinvolge allenatori ? 1 per dire si -- altro per dire no");
					int risp = in.nextInt();
								
					if (risp == 1)
					{
						System.out.println("Inserisci CF allenatore:");
						String cfC = s.nextLine();
						
						
						//verifico se l'allenatore scelto dall''utente esiste nel dB
						rs = this.s.executeQuery(" select Cf \r\n" + 
								"from allenatore\r\n");
						
						presente = false;
						while(rs.next())
						{
							String nomeDB=rs.getString("Cf");
							if( cfC.equalsIgnoreCase(nomeDB) )
							{
								presente = true;
								this.s.executeUpdate(" insert into coinvolgimento \r\n" +
										"( codiceattivita ,  ) "+
										"values ("  + "'" +attivitaIn +"'" + ","  
														+ "'" +cfC   + "'"  + ")" );
							}
						}	
						
						if(!presente)
						{
							System.out.println("Allenatore non presente nel db");
							System.out.println("Errore nel coinvolgimento dell allenatore");
						}
					}
				}
			}
		}
		
		
	
		
		

	
	Scanner in = new Scanner(System.in);
	Scanner menuLine = new Scanner(System.in);
	//Variabili d'istanza
	private Statement s;
	private ResultSet rs;
}
